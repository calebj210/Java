/**
 * Linked list node definition
 * 
 * Date Last Modified: 01/21/2021
 * @author Caleb Jacobs
 * 
 * CS2321
 * Spring 2021
 */

public class ListNode {
	int val;
	ListNode next;
	ListNode(int x) { val = x; }
}